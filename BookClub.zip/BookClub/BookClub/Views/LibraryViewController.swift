//
//  LibraryViewController.swift
//  BookClub
//
//  Created by Filip Panchevski on 9/9/21.
//  Copyright © 2021 Filip Panchevski. All rights reserved.
//

import Foundation
import UIKit
import FirebaseStorage
import Firebase
import FirebaseAuth

class LibraryViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    
    
    @IBOutlet weak var titleInput: UITextField!
    @IBOutlet weak var authorInput: UITextField!
    @IBOutlet weak var ratingInput: UITextField!
    @IBOutlet weak var genreInput: UITextField!
    @IBOutlet weak var storyInput: UITextField!
    @IBOutlet weak var bookCoverImage: UIImageView!
    @IBOutlet weak var addImageButton: UIButton!
    
    var imgurl = ""
    
    
    let storage = Storage.storage(url: "gs://bookclub-6fcb1.appspot.com").reference()
    let db = Firestore.firestore()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        bookCoverImage.contentMode = .scaleAspectFit
        bookCoverImage.isHidden = true
    }
    
    
    @IBAction func addBookButton(_ sender: Any) {
        let bookTitle = titleInput.text
        let author = authorInput.text
        let rating = Int(ratingInput.text ?? "3")
        let genre = genreInput.text
        let story = storyInput.text
        let url = UserDefaults.standard.value(forKey: "url") as? String
        print("url \(url)")
        print("imgurl \(imgurl)")
        
        if bookTitle == "" || author == "" || genre == "" || story == "" || url == ""
        {
            showToast(message: "Please fill in all the fields", font: .systemFont(ofSize: 12.0), view: self.view)
            return
        }
        else
        {
            _ = self.db.collection("books").addDocument(data: [
                "author": author,
                "genre": genre,
                "imageURL": url,
                "rating": rating,
                "story": story,
                "title": bookTitle,
                "uid": Auth.auth().currentUser?.uid
            ]) { err in
                if let err = err {
                    showToast(message: "Error adding document: \(err.localizedDescription)", font: .systemFont(ofSize: 12.0), view: self.view);
                } else {
                    self.performSegue(withIdentifier: "backToBooks", sender: self)
                }
            }
        }
    }
    
    
    @IBAction func cancel(_ sender: Any) {
        performSegue(withIdentifier: "backToBooks", sender: self)
    }
    
    @IBAction func uploadImageButton(_ sender: Any) {
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.delegate = self
        picker.allowsEditing = true
        present(picker, animated: true)
        print("picker selected")
    }
    
   public func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any])
    {
        self.dismiss(animated: true, completion: nil)
        
        guard let image = info[UIImagePickerController.InfoKey.editedImage] as? UIImage else {
            return
        }
        
        guard let imageData = image.pngData() else {
            return
        }
        
        //upload img, download url, and save url to books database
        bookCoverImage.image = UIImage(data: imageData)
        bookCoverImage.isHidden = false
        addImageButton.isHidden = true
        storage.listAll { (storageList, error) in
            guard error == nil else
            {
                print("Failed")
                return
            }
            let id = storageList.items.count+1
            print("num of pics \(id)")
            self.storage.child("\(id)").putData(imageData, metadata: nil, completion: {_, error in
                guard error == nil else
                {
                    print("Failed to upload")
                    return
                }
                self.storage.child("\(id)").downloadURL(completion: {url, error in
                    guard let url = url, error == nil else
                    {
                        return
                    }
                    
                    let urlString = url.absoluteString
                    print(urlString)
                    showToast(message: urlString, font: .systemFont(ofSize: 12.0), view: self.view)
                    UserDefaults.standard.set(urlString, forKey: "url")
                    self.imgurl = urlString
                    
                })
            })
        }
        
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController)
    {
        picker.dismiss(animated: true, completion: nil)
    }
    
}
}
