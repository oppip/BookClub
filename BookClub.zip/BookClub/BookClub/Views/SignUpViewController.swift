//
//  SignUpViewController.swift
//  BookClub
//
//  Created by Filip Panchevski on 9/9/21.
//  Copyright © 2021 Filip Panchevski. All rights reserved.
//

import Foundation
import UIKit
import Firebase
import FirebaseFirestore
import FirebaseAuth

class SignUpViewController: UIViewController {
    
    
    @IBOutlet weak var nameInput: UITextField!
    @IBOutlet weak var emailInput: UITextField!
    @IBOutlet weak var contactInput: UITextField!
    @IBOutlet weak var passwordInput: UITextField!
    @IBOutlet weak var confirmPasswordInput: UITextField!
    
    var emailLog = String()
    var passwordLog = String()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        emailInput.text = emailLog
        passwordInput.text = passwordLog
    }
    
    @IBAction func logInButton(_ sender: Any) {
        performSegue(withIdentifier: "signUpToLogIn", sender: self)
        if (emailInput.text != "") || (passwordInput.text != "")
        {
            func prepare(for segue: UIStoryboardSegue, sender: Any?) {
                if segue.identifier == "signUpToLogIn" {
                    if let nextViewController = segue.destination as? LogInViewController {
                        nextViewController.emailInput.text = emailInput.text //Or pass any values
                        nextViewController.passwordInput.text = passwordInput.text
                    }
                }
            }
        }
    }
    
    @IBAction func signUpButton(_ sender: Any) {
        //check if all fields are filled
        if validateFields()
        {
            Auth.auth().createUser(withEmail: emailInput.text!, password: passwordInput.text!) { (result, err) in
                //check for errors
                if err != nil
                {
                    showToast(message: err as! String, font: .systemFont(ofSize: 12.0), view: self.view)
                }
                else
                {
                    let db = Firestore.firestore()
                    let name = self.nameInput.text!.trimmingCharacters(in: .whitespacesAndNewlines)
                    let contact = self.contactInput.text!.trimmingCharacters(in: .whitespacesAndNewlines)
                    // Add a new document with a generated ID
                    db.collection("users").document(result!.user.uid).setData([
                        "full_name": name,
                        "contact": contact,
                        "uid": result!.user.uid
                    ]) { err in
                        if let err = err {
                            showToast(message: "Error adding document: \(err.localizedDescription)", font: .systemFont(ofSize: 12.0), view: self.view);
                        } else {
                            self.performSegue(withIdentifier: "SuccessfulSignUp", sender: self)
                        }
                    }
                }
            }
        }
    }
    
    func validateFields() -> Bool {
        if emailInput.text == "" || passwordInput.text == "" || contactInput.text == "" || nameInput.text == "" || confirmPasswordInput.text == ""
        {
            showToast(message: "Please fill in all fields", font: .systemFont(ofSize: 12.0), view: self.view);
            return false;
        }
        return true;
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? LogInViewController {
            vc.emailSign = emailInput.text ?? ""
            vc.passwordSign = passwordInput.text ?? ""
        }
    }
    
}
