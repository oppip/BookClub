//
//  BookClubViewController.swift
//  BookClub
//
//  Created by Filip Panchevski on 9/9/21.
//  Copyright © 2021 Filip Panchevski. All rights reserved.
//

import Foundation
import UIKit
import FirebaseFirestore
import Firebase
import FirebaseAuth

class BookClubViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {

    let db = Firestore.firestore()
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        var res: Int = 0
        db.collection("books")
            .getDocuments() { (querySnapshot, err) in
                    if err != nil
                    {
                        showToast(message: err!.localizedDescription, font: .systemFont(ofSize: 12.0), view: self.view)
                        return
                    }
                
                res = querySnapshot!.count
                UserDefaults.standard.set(res, forKey: "numOfBooks")
                //print("num of documents \(UserDefaults.standard.value(forKey: "numOfBooks")!)")
                
        }
        //print("num of documents outside \(UserDefaults.standard.value(forKey: "numOfBooks")!)")
        return UserDefaults.standard.value(forKey: "numOfBooks")! as! Int
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! MyCollectionCell
        
        
        
        db.collection("books").getDocuments() { (querySnapshot, err) in
            if err != nil
            {
                showToast(message: err!.localizedDescription, font: .systemFont(ofSize: 12.0), view: self.view)
                return
            }
            
            let document = querySnapshot!.documents[indexPath.row]
        
            cell.bookAuthor.text = document.data()["author"] as? String
            cell.bookTitle.text = document.data()["title"] as? String
            let url = URL(string: document.data()["imageURL"] as! String)
            let data = try? Data(contentsOf: url!)
            cell.bookCover.image = UIImage(	data: data!)
            cell.bookStory.text = document.data()["story"] as? String
            cell.bookGenre.text = document.data()["genre"] as? String
            cell.bookRating.text = String(repeating: "⭐", count: (document.data()["rating"] as? Int)!)
            self.db.collection("users").document((document.data()["uid"] as? String)!).getDocument(completion: { (querySnapshotUser, err) in
                    if err != nil
                    {
                        showToast(message: err!.localizedDescription, font: .systemFont(ofSize: 12.0), view: self.view)
                        return
                    }
                cell.bookLender.text = querySnapshotUser!.data()?["full_name"] as? String
                })
        }
        cell.bookTitle.adjustsFontSizeToFitWidth = true
        cell.bookLender.adjustsFontSizeToFitWidth = true
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        db.collection("books").getDocuments() { (querySnapshot, err) in
            if err != nil
            {
                showToast(message: err!.localizedDescription, font: .systemFont(ofSize: 12.0), view: self.view)
                return
            }
            
            let document = querySnapshot!.documents[indexPath.row]
            UserDefaults.standard.set(document.documentID, forKey: "bookForRequest")
        
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3)
            {
                self.performSegue(withIdentifier: "mapRequest", sender: self)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func logOut(_ sender: Any) {
        if let result = try? Auth.auth().signOut() {
            print("Result was \(result)")
        } else {
            print("D'oh.")
        }
        performSegue(withIdentifier: "logOut", sender: self)
    }
    
    @IBAction func addBookButton(_ sender: Any) {
        performSegue(withIdentifier: "addBook", sender: self)
    }
    
}
