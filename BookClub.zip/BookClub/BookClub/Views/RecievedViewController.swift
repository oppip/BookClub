//
//  RecievedViewController.swift
//  BookClub
//
//  Created by Filip Panchevski on 9/9/21.
//  Copyright © 2021 Filip Panchevski. All rights reserved.
//

import Foundation
import UIKit
import MapKit
import Firebase
import FirebaseAuth
import FirebaseStorage

class RecievedViewController: UITableViewController{
    
    let db = Firestore.firestore()
    var keys: [String] = []
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var res: Int = 0
        db.collection("requests")
            .getDocuments { (querySnapshot, err) in
                if err != nil
                {
                    showToast(message: err!.localizedDescription, font: .systemFont(ofSize: 12.0), view: self.view)
                    return
                }
                
                for x in querySnapshot!.documents
                {
                    if x.data()["lenderUID"] as? String == Auth.auth().currentUser?.uid
                    {
                        res += 1
                    }
                }
                UserDefaults.standard.set(res, forKey: "numOfRequests")
        }
        //print("num of requests \(String(describing: UserDefaults.standard.value(forKey: "numOfRequests")))")
        return UserDefaults.standard.value(forKey: "numOfRequests") as? Int ?? 1
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "recievedCell", for: indexPath) as! RecievedViewCell
        
        db.collection("requests")
            .getDocuments(completion: { (querySnapshot, err) in
                if err != nil
                {
                    showToast(message: err!.localizedDescription, font: .systemFont(ofSize: 12.0), view: self.view)
                    return
                }
                for document in querySnapshot!.documents
                {
                    if (document.data()["lenderUID"] as? String == Auth.auth().currentUser?.uid) && !(self.keys.contains(document.documentID))
                    {
                        self.keys.append(document.documentID)
                        print(self.keys)
                    }
                }
                
                self.db.collection("requests").document(self.keys[indexPath.row])
                    .getDocument(completion: { (querySnapshot, err) in
                        if err != nil
                        {
                            showToast(message: err!.localizedDescription, font: .systemFont(ofSize: 12.0), view: self.view)
                            return
                        }
                        
                        self.db.collection("users").document((querySnapshot!.data()!["borowerUID"] as? String)!)
                            .getDocument(completion: { (querySnapshotUser, err) in
                                if err != nil
                                {
                                    showToast(message: err!.localizedDescription, font: .systemFont(ofSize: 12.0), view: self.view)
                                    return
                                }
                                cell.userName.text = querySnapshotUser!.data()?["full_name"] as? String
                                cell.userRating.text = querySnapshotUser!.data()!["contact"] as? String
                            })
                        
                        self.db.collection("books").document((querySnapshot!.data()!["bookID"] as? String)!)
                            .getDocument(completion: { (querySnapshot, err) in
                                if err != nil
                                {
                                    showToast(message: err!.localizedDescription, font: .systemFont(ofSize: 12.0), view: self.view)
                                    return
                                }
                                cell.bookTitle.text = querySnapshot!.data()!["title"] as? String
                            })
                        cell.dateTime.text = querySnapshot!.data()!["date"] as? String
                        cell.bookTitle.adjustsFontSizeToFitWidth = true
                        cell.userName.adjustsFontSizeToFitWidth = true
                        cell.mapRequested.isUserInteractionEnabled = false
                        
                        switch querySnapshot!.data()!["status"] as! String
                        {
                        case "accept":
                            cell.cellBG.backgroundColor = UIColor.init(red: 127/255, green: 191/255, blue: 127/255, alpha: 1.0)
                        case "reject":
                            cell.cellBG.backgroundColor = UIColor.init(red: 246/255, green: 129/255, blue: 129/255, alpha: 1.0)
                        default:
                            cell.cellBG.backgroundColor = UIColor.init(red: 255/255, green: 255/255, blue: 153/255, alpha: 1.0)
                        }
                        
                        let span = MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005)
                        let coordinate = CLLocationCoordinate2D(latitude: querySnapshot!.data()!["latitude"] as! Double, longitude: querySnapshot!.data()!["longitude"] as! Double)
                        let region = MKCoordinateRegion(center: coordinate, span: span)
                        cell.mapRequested.setRegion(region, animated: true)
                        
                        let newLocation = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
                        var title = ""
                        CLGeocoder().reverseGeocodeLocation(newLocation, completionHandler: {(placemarks, error) in
                            if error != nil
                            {
                                print(error!)
                            }
                            else
                            {
                                if let placemark = placemarks?[0]
                                {
                                    if placemark.subThoroughfare != nil
                                    {
                                        title += placemark.subThoroughfare! + " "
                                    }
                                    if placemark.thoroughfare != nil
                                    {
                                        title += placemark.thoroughfare!
                                    }
                                }
                                if title == ""
                                {
                                    title = "Here"
                                }
                            }
                            
                        let annotation = MKPointAnnotation()
                        annotation.coordinate = newLocation.coordinate
                        annotation.title = title
                        cell.mapRequested.addAnnotation(annotation)
                        })
                    })
        })
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 268.0
    }
    
    override func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        let editAction = UITableViewRowAction(style: .normal, title: "Accept") { (rowAction, indexPath) in
            //TODO: edit the row at indexPath here
            
            self.db.collection("requests")
                .getDocuments(completion: { (querySnapshot, err) in
                    if err != nil
                    {
                        showToast(message: err!.localizedDescription, font: .systemFont(ofSize: 12.0), view: self.view)
                        return
                    }
                    for document in querySnapshot!.documents
                    {
                        if (document.data()["lenderUID"] as? String == Auth.auth().currentUser?.uid) && !(self.keys.contains(document.documentID))
                        {
                            self.keys.append(document.documentID)
                            print(self.keys)
                        }
                    }
                    
                    self.db.collection("requests").document(self.keys[indexPath.row]).updateData(["status" : "accept"])
                })
            tableView.reloadRows(at: [indexPath], with: .left)
        }
        editAction.backgroundColor = .green
        
        let deleteAction = UITableViewRowAction(style: .normal, title: "Reject") { (rowAction, indexPath) in
            //TODO: Delete the row at indexPath here
            
            self.db.collection("requests")
                .getDocuments(completion: { (querySnapshot, err) in
                    if err != nil
                    {
                        showToast(message: err!.localizedDescription, font: .systemFont(ofSize: 12.0), view: self.view)
                        return
                    }
                    for document in querySnapshot!.documents
                    {
                        if (document.data()["lenderUID"] as? String == Auth.auth().currentUser?.uid) && !(self.keys.contains(document.documentID))
                        {
                            self.keys.append(document.documentID)
                            print(self.keys)
                        }
                    }
                    
                    self.db.collection("requests").document(self.keys[indexPath.row]).updateData(["status" : "reject"])
                })
            tableView.reloadRows(at: [indexPath], with: .left)
        }
        deleteAction.backgroundColor = .red
        
        return [editAction,deleteAction]
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
}
