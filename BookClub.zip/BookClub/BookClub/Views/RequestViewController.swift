//
//  RequestViewController.swift
//  BookClub
//
//  Created by Filip Panchevski on 9/9/21.
//  Copyright © 2021 Filip Panchevski. All rights reserved.
//

import Foundation
import UIKit
import MapKit
import Firebase
import FirebaseAuth

class RequestViewController: UIViewController {
    
    @IBOutlet weak var mapInput: MKMapView!
    @IBOutlet weak var userLender: UILabel!
    @IBOutlet weak var bookTitle: UILabel!
    @IBOutlet weak var userContact: UILabel!
    @IBOutlet weak var dateSetter: UIDatePicker!
    
    
    let db = Firestore.firestore()
    let doc = UserDefaults.standard.value(forKey: "bookForRequest") as? String
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        let longPressGR = UILongPressGestureRecognizer(target: self, action: #selector(RequestViewController.longpress(gestureRecognizer:)))
        longPressGR.minimumPressDuration = 1
        mapInput.addGestureRecognizer(longPressGR)
        if doc == nil
        {
            showToast(message: "Error from request", font: .systemFont(ofSize: 12.0), view: self.view)
            return
        }
        else
        {
            db.collection("books").document(doc!).getDocument{ (querySnapshot, err) in
            if err != nil
            {
                showToast(message: err!.localizedDescription, font: .systemFont(ofSize: 12.0), view: self.view)
                return
            }
                self.db.collection("users").document((querySnapshot!.data()!["uid"] as? String)!).getDocument(completion: { (querySnapshotUser, err) in
                if err != nil
                {
                    showToast(message: err!.localizedDescription, font: .systemFont(ofSize: 12.0), view: self.view)
                    return
                }
                self.userLender.text = querySnapshotUser!.data()?["full_name"] as? String
                self.userContact.text = querySnapshotUser!.data()?["contact"] as? String
                   
            })
            
                self.bookTitle.text = querySnapshot!.data()!["title"] as? String
            
            }
            
            let span = MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
            let coordinate = CLLocationCoordinate2D(latitude: 41.9981, longitude: 21.4254)
            let region = MKCoordinateRegion(center: coordinate, span: span)
            self.mapInput.setRegion(region, animated: true)
            
            
        }
        bookTitle.adjustsFontSizeToFitWidth = true
        userLender.adjustsFontSizeToFitWidth = true
    }
    
    @objc func longpress(gestureRecognizer: UILongPressGestureRecognizer)
    {
        print("longpress")
        
        if gestureRecognizer.state == UILongPressGestureRecognizer.State.began
        {
            let touchPoint = gestureRecognizer.location(in: self.mapInput)
            let newCoordinate = self.mapInput.convert(touchPoint, toCoordinateFrom: self.mapInput)
            let newLocation = CLLocation(latitude: newCoordinate.latitude, longitude: newCoordinate.longitude)
            print(newLocation)
            var title = ""
            CLGeocoder().reverseGeocodeLocation(newLocation, completionHandler: {(placemarks, error) in
                if error != nil
                {
                    print(error!)
                }
                else
                {
                    if let placemark = placemarks?[0]
                    {
                        if placemark.subThoroughfare != nil
                        {
                            title += placemark.subThoroughfare! + " "
                        }
                        if placemark.thoroughfare != nil
                        {
                            title += placemark.thoroughfare!
                        }
                    }
                    if title == ""
                    {
                        title = "Added \(NSDate())"
                    }
                }
                let annotation = MKPointAnnotation()
                annotation.coordinate = newLocation.coordinate
                print(title)
                annotation.title = title
                self.mapInput.addAnnotation(annotation)
                UserDefaults.standard.set(newCoordinate.latitude, forKey: "lastLatitude")
                UserDefaults.standard.set(newCoordinate.longitude, forKey: "lastLongitude")
                
            })
        }
    }
    
    @IBAction func cancelRequest(_ sender: Any) {
        performSegue(withIdentifier: "requestToBookClub", sender: self)
    }
    
    @IBAction func sendRequest(_ sender: Any) {
    
        //send request and put in firebase
        let latitude = UserDefaults.standard.value(forKey: "lastLatitude") as? Double
        let longitude = UserDefaults.standard.value(forKey: "lastLongitude") as? Double
        let date = getDate(date: self.dateSetter.date)
        
        //let date = getDate(self.dateSetter.debugDescription)
        if latitude == nil || longitude == nil || date == ""
        {
            if date == ""
            {
                showToast(message: "Please select a future date", font: .systemFont(ofSize: 12.0), view: self.view)
            }
            else
            {
                showToast(message: "Please select a location", font: .systemFont(ofSize: 12.0), view: self.view)
            }
            
        }
        else
        {
            db.collection("books").document(doc!).getDocument{ (querySnapshot, err) in
                if err != nil
                {
                    showToast(message: err!.localizedDescription, font: .systemFont(ofSize: 12.0), view: self.view)
                    return
                }
                self.db.collection("users").document((querySnapshot!.data()!["uid"] as? String)!).getDocument(completion: { (querySnapshotUser, err) in
                    if err != nil
                    {
                        showToast(message: err!.localizedDescription, font: .systemFont(ofSize: 12.0), view: self.view)
                        return
                    }
                    
                    _ = self.db.collection("requests").addDocument(data: [
                        "bookID": querySnapshot?.documentID ?? "Error, no bookID",
                        "lenderUID": querySnapshotUser!.data()?["uid"] as? String ?? "Error, no user lender found.",
                        "borowerUID": Auth.auth().currentUser?.uid ?? "Error, no logged in user",
                        "latitude": latitude ?? 41.9981,
                        "longitude": longitude ?? 21.4254,
                        "date": date,
                        "status": "pending"
                    ]) { err in
                        if let err = err {
                            showToast(message: "Error adding document: \(err.localizedDescription)", font: .systemFont(ofSize: 12.0), view: self.view);
                        } else {
                            self.performSegue(withIdentifier: "requestToBookClub", sender: self)
                        }
                    }
                    
                })
            }
        }
    }
    
    func getDate(date: Date) -> String
    {
        let dateFormat = DateFormatter()
        dateFormat.dateFormat = "MMM d, HH:mm"
        
        if(date < Date.init(timeIntervalSinceNow: 0))
        {
            return ""
        }
        else if (date == Date.init(timeIntervalSinceNow: 0))
        {
            return "Anytime"
        }
        else
        {
            return dateFormat.string(from: date)
        }
        
    }
    
}


