//
//  MyCollectionCell.swift
//  BookClub
//
//  Created by Filip Panchevski on 9/10/21.
//  Copyright © 2021 Filip Panchevski. All rights reserved.
//

import UIKit

class MyCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var bookCover: UIImageView!
    @IBOutlet weak var bookTitle: UILabel!
    @IBOutlet weak var bookAuthor: UILabel!
    @IBOutlet weak var bookRating: UILabel!
    @IBOutlet weak var bookStory: UITextView!
    @IBOutlet weak var bookGenre: UILabel!
    @IBOutlet weak var bookLender: UILabel!
    
    
    
    
    
}
