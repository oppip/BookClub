//
//  LogInViewController.swift
//  BookClub
//
//  Created by Filip Panchevski on 9/9/21.
//  Copyright © 2021 Filip Panchevski. All rights reserved.
//

import Foundation
import UIKit
import Firebase
import FirebaseAuth
import FirebaseFirestore

class LogInViewController: UIViewController {
    
    @IBOutlet weak var emailInput: UITextField!
    @IBOutlet weak var passwordInput: UITextField!
    
    var emailSign = String()
    var passwordSign = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        emailInput.text = emailSign
        passwordInput.text = passwordSign
    }
    
    @IBAction func logInButton(_ sender: Any) {
        //validate fields and authenticate
        if validateFields()
        {
            Auth.auth().signIn(withEmail: emailInput.text!, password: passwordInput.text!) { (result, error) in
                if error != nil{
                    //cant sign in
                    showToast(message: error!.localizedDescription, font: .systemFont(ofSize: 12.0), view: self.view)
                }
                else
                {
                    showToast(message: "Welcome!", font: .systemFont(ofSize: 12.0), view: self.view)
                    self.performSegue(withIdentifier: "SuccessfulLogIn", sender: self)
                }
            }
        }
        
    }
    
    //check if fields are null
    func validateFields() -> Bool
    {
        if emailInput.text == "" || passwordInput.text == ""
        {
            showToast(message: "Please fill in all fields", font: .systemFont(ofSize: 12.0), view: self.view);
            return false;
        }
        return true;
        
    }
    
    
    @IBAction func signUpButton(_ sender: Any) {
        performSegue(withIdentifier: "logInToSignUp", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? SignUpViewController {
            vc.emailLog = emailInput.text ?? ""
            vc.passwordLog = passwordInput.text ?? ""
        }
    }
    
    
}
