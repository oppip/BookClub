//
//  SentViewCell.swift
//  BookClub
//
//  Created by Filip Panchevski on 9/12/21.
//  Copyright © 2021 Filip Panchevski. All rights reserved.
//

import UIKit
import MapKit

class SentViewCell: UITableViewCell {

    
    @IBOutlet weak var bookTitle: UILabel!
    @IBOutlet weak var dateTime: UILabel!
    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var userRating: UILabel!
    @IBOutlet weak var mapSent: MKMapView!
    @IBOutlet weak var cellBG: UIView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
