//
//  BookView.swift
//  BookClub
//
//  Created by Filip Panchevski on 9/6/21.
//  Copyright © 2021 Filip Panchevski. All rights reserved.
//

import Foundation
